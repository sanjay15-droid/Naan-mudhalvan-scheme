# Script-Controlled ACL – Creation of Users and Roles

Naan Mudhalvan / Skill Wallet project

## Project Title
**Script-Controlled ACL – Restrict Record Access Based on User and Field Conditions**

This repository contains the ServiceNow project files and documentation for creating the users and roles required for a script-controlled Access Control List (ACL).

## Milestone 1 – Creation of Users and Roles

### Objective
Create the required ServiceNow roles and test users so that ACL rules can later be tested using different access levels.

### Roles
- `acl_admin` – administrator/testing role
- `acl_manager` – manager-level access
- `acl_user` – normal user access

### Test Users
The setup script creates these sample accounts:
- `acl.admin`
- `acl.manager`
- `acl.user`

**Important:** The script uses a temporary password placeholder. Change it before using the project in a real ServiceNow instance.

## Repository Structure

```text
Creation-of-Users-and-Roles/
├── README.md
├── .gitignore
├── docs/
│   ├── milestone-1.md
│   ├── test-plan.md
│   └── project-overview.md
└── servicenow/
    ├── scripts/
    │   ├── 01_create_roles_and_users.js
    │   ├── 02_verify_roles_and_users.js
    │   └── 03_sample_acl_script.js
    └── acl/
        └── record_read_acl.js
```

## Requirements

- ServiceNow instance
- Administrator access
- Access to **System Definition > Scripts - Background**
- A custom table containing the field used by the ACL
- Test users and roles

## How to Use

1. Open the ServiceNow instance.
2. Log in with an administrator account.
3. Go to **System Definition > Scripts - Background**.
4. Open `servicenow/scripts/01_create_roles_and_users.js`.
5. Replace the temporary password placeholder.
6. Run the script.
7. Run `02_verify_roles_and_users.js` to verify the records.
8. Create/configure the custom table.
9. Use `servicenow/acl/record_read_acl.js` as the starting point for the scripted Read ACL.
10. Test the ACL with each test user.

## Security Note

Never commit real passwords, API keys, instance credentials, or personal user information to GitHub.
