# GitHub Upload Guide

## 1. Create Repository

Create a new GitHub repository named:

`script-controlled-acl-users-and-roles`

## 2. Upload Files

Upload the complete contents of this folder.

## 3. Commit Message

Use:

`Add Milestone 1 users and roles setup`

## 4. Repository Description

You can use:

`ServiceNow Script-Controlled ACL project for creating users, roles and role-based record access.`

## 5. Important

Before publishing:
- Remove real passwords.
- Remove ServiceNow instance URLs if they are private.
- Remove personal email addresses.
- Do not upload credentials or screenshots containing private information.
