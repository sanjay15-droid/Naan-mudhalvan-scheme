# Milestone 1 – Creation of Users and Roles

## Objective

Create test roles and users that can be used to validate the Script-Controlled ACL.

## Roles

| Role | Purpose |
|---|---|
| acl_admin | Full project/testing access |
| acl_manager | Manager-level access |
| acl_user | Normal user access |

## Users

| User name | Role |
|---|---|
| acl.admin | acl_admin |
| acl.manager | acl_manager |
| acl.user | acl_user |

## Expected Result

After executing the setup script:

- All three roles exist.
- All three users exist.
- Each user has the correct role.
- The users can be used for ACL testing.

## Verification

Run the verification script and confirm the console output shows each role and user.
