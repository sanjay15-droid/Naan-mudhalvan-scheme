# Project Overview

## Problem Statement

The project implements a script-controlled ServiceNow ACL that restricts record access based on user and field conditions.

The ACL checks specific field values and user conditions. A record is accessible only when the ACL script evaluates to `true`.

## Main Components

1. Users
2. Roles
3. Custom table/records
4. Scripted ACL
5. Test cases

## Milestones

1. Creation of Users and Roles
2. Tables Creation
3. Creation of Access Control List – READ
4. Creation of Access Control List – CREATE
5. Creation of Access Control List – WRITE
6. Creation of Access Control List – DELETE
7. Conclusion

## Skills Used

- ServiceNow
- Server-side scripting
- Access Control Lists
- JavaScript
- Role-based access control
