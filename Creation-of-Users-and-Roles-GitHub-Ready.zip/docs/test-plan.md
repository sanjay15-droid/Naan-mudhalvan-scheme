# Test Plan

## User and Role Tests

| Test | Expected Result |
|---|---|
| Search for `acl_admin` role | Role exists |
| Search for `acl_manager` role | Role exists |
| Search for `acl_user` role | Role exists |
| Search for `acl.admin` | User exists |
| Search for `acl.manager` | User exists |
| Search for `acl.user` | User exists |
| Check acl.admin roles | acl_admin assigned |
| Check acl.manager roles | acl_manager assigned |
| Check acl.user roles | acl_user assigned |

## ACL Testing

Use the three users to test records with different field values. The scripted ACL should return `true` only when the configured user and record conditions are satisfied.
