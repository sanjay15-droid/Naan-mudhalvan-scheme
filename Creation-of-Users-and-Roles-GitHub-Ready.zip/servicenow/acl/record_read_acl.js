/*
 * Read ACL – Script Controlled Record Access
 *
 * Replace `x_your_scope_your_table` with your actual table.
 * Replace `access_level` with your actual field.
 *
 * ACL operation: read
 */

answer = false;

if (gs.hasRole('acl_admin')) {
    answer = true;
} else if (gs.hasRole('acl_manager') && current.access_level == 'manager') {
    answer = true;
} else if (gs.hasRole('acl_user') && current.access_level == 'user') {
    answer = true;
}
