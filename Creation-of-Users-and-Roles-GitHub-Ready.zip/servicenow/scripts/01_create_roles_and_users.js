/*
 * Naan Mudhalvan Project
 * Milestone 1: Creation of Users and Roles
 *
 * Run from:
 * System Definition > Scripts - Background
 *
 * IMPORTANT:
 * 1. Replace TEMP_PASSWORD before running.
 * 2. Do not commit real passwords to GitHub.
 */

(function () {
    var TEMP_PASSWORD = 'CHANGE_THIS_PASSWORD';

    var roles = [
        { name: 'acl_admin', description: 'Administrator/testing role for Script-Controlled ACL project' },
        { name: 'acl_manager', description: 'Manager-level role for Script-Controlled ACL project' },
        { name: 'acl_user', description: 'Normal user role for Script-Controlled ACL project' }
    ];

    var users = [
        { user_name: 'acl.admin', first_name: 'ACL', last_name: 'Admin', email: 'acl.admin@example.invalid', role: 'acl_admin' },
        { user_name: 'acl.manager', first_name: 'ACL', last_name: 'Manager', email: 'acl.manager@example.invalid', role: 'acl_manager' },
        { user_name: 'acl.user', first_name: 'ACL', last_name: 'User', email: 'acl.user@example.invalid', role: 'acl_user' }
    ];

    function getOrCreateRole(roleData) {
        var role = new GlideRecord('sys_user_role');
        role.addQuery('name', roleData.name);
        role.query();

        if (role.next()) {
            gs.info('Role already exists: ' + roleData.name);
            return role.sys_id.toString();
        }

        role.initialize();
        role.name = roleData.name;
        role.description = roleData.description;
        var roleId = role.insert();
        gs.info('Created role: ' + roleData.name);
        return roleId.toString();
    }

    function getOrCreateUser(userData) {
        var user = new GlideRecord('sys_user');
        user.addQuery('user_name', userData.user_name);
        user.query();

        if (user.next()) {
            gs.info('User already exists: ' + userData.user_name);
            return user.sys_id.toString();
        }

        user.initialize();
        user.user_name = userData.user_name;
        user.first_name = userData.first_name;
        user.last_name = userData.last_name;
        user.email = userData.email;
        user.password = TEMP_PASSWORD;
        user.active = true;

        var userId = user.insert();
        gs.info('Created user: ' + userData.user_name);
        return userId.toString();
    }

    function assignRole(userId, roleId) {
        var relation = new GlideRecord('sys_user_has_role');
        relation.addQuery('user', userId);
        relation.addQuery('role', roleId);
        relation.query();

        if (relation.next()) {
            gs.info('Role already assigned.');
            return;
        }

        relation.initialize();
        relation.user = userId;
        relation.role = roleId;
        relation.insert();
        gs.info('Role assigned.');
    }

    var roleIds = {};
    for (var i = 0; i < roles.length; i++) {
        roleIds[roles[i].name] = getOrCreateRole(roles[i]);
    }

    for (var j = 0; j < users.length; j++) {
        var userId = getOrCreateUser(users[j]);
        assignRole(userId, roleIds[users[j].role]);
    }

    gs.info('=== Milestone 1 setup completed ===');
})();
