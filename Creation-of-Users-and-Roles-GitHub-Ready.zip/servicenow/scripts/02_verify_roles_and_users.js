/*
 * Verification script
 * Run from System Definition > Scripts - Background
 */

(function () {
    var roleNames = ['acl_admin', 'acl_manager', 'acl_user'];
    var userNames = ['acl.admin', 'acl.manager', 'acl.user'];

    gs.info('=== ROLES ===');
    for (var i = 0; i < roleNames.length; i++) {
        var role = new GlideRecord('sys_user_role');
        role.addQuery('name', roleNames[i]);
        role.query();

        gs.info(role.next()
            ? 'FOUND ROLE: ' + roleNames[i]
            : 'MISSING ROLE: ' + roleNames[i]);
    }

    gs.info('=== USERS ===');
    for (var j = 0; j < userNames.length; j++) {
        var user = new GlideRecord('sys_user');
        user.addQuery('user_name', userNames[j]);
        user.query();

        if (user.next()) {
            gs.info('FOUND USER: ' + userNames[j]);

            var role = new GlideRecord('sys_user_has_role');
            role.addQuery('user', user.sys_id);
            role.query();

            while (role.next()) {
                gs.info('  ROLE: ' + role.role.name);
            }
        } else {
            gs.info('MISSING USER: ' + userNames[j]);
        }
    }
})();
