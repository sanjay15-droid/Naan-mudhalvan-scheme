/*
 * Sample Script-Controlled ACL condition.
 *
 * Adapt the field names to your custom table.
 * This example allows:
 *   - acl_admin to access every record
 *   - acl_manager when the record's access_level is 'manager'
 *   - acl_user when the record's access_level is 'user'
 *
 * Use this logic inside the Script field of a ServiceNow ACL.
 */

answer = false;

if (gs.hasRole('acl_admin')) {
    answer = true;
} else if (gs.hasRole('acl_manager') && current.access_level == 'manager') {
    answer = true;
} else if (gs.hasRole('acl_user') && current.access_level == 'user') {
    answer = true;
}
